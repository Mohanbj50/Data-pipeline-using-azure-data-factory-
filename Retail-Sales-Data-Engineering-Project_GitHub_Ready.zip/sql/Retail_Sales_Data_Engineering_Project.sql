
-- Create Table
CREATE TABLE sales (
    Order_ID INT,
    Customer_ID INT,
    Product VARCHAR(50),
    Region VARCHAR(50),
    Sales INT,
    Order_Date DATE
);

-- Total Sales by Region
SELECT Region, SUM(Sales) AS Total_Sales
FROM sales
GROUP BY Region;

-- Monthly Sales Trend
SELECT YEAR(Order_Date) AS Year,
       MONTH(Order_Date) AS Month,
       SUM(Sales) AS Monthly_Sales
FROM sales
GROUP BY YEAR(Order_Date), MONTH(Order_Date)
ORDER BY Year, Month;

-- Top 5 Customers
SELECT Customer_ID,
       SUM(Sales) AS Total_Sales,
       RANK() OVER (ORDER BY SUM(Sales) DESC) AS Rank_Position
FROM sales
GROUP BY Customer_ID;

-- Create Index for Performance
CREATE INDEX idx_customer ON sales(Customer_ID);
