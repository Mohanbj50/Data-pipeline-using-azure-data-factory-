# Retail Sales Data Engineering Project

## Project Overview

End-to-end ETL pipeline using Python, SQL, and Power BI.

## Architecture

CSV → Python Cleaning → SQL Transformation → Power BI Dashboard

## Tech Stack

-   Python (Pandas)
-   SQL
-   Azure (Conceptual)
-   Power BI

## Key KPIs

-   Total Sales
-   Regional Performance
-   Monthly Growth
-   Top Customers

## How to Run

1.  Load CSV dataset.
2.  Run Python cleaning script.
3.  Execute SQL transformation queries.
4.  Connect Power BI for visualization.
